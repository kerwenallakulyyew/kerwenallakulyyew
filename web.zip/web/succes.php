
<!DOCTYPE html>
<html lang="tk">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Satyn Alyş Üstünlikli Tamamlandy</title>
    <link rel="stylesheet" href="style.css"> <!-- CSS stilini bagla -->
</head>
<body>
    <div class="container">
        <h1>Satyn Alyşyňyz Üstünlikli Tamamlandy!</h1>
        <p>Az wagtdan soň size SMS habar berler. Gowy günler!</p>
        <a href="index.php" class="button">Ana Sahypa Gaýdyp Giriş</a>
    </div>
</body>
</html>
